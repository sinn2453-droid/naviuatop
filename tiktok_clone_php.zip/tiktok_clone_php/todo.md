# TikTok Clone - Project TODO

## Database & Schema
- [x] Design and create database tables (users, videos, comments, likes, subscriptions, coins, gifts)
- [x] Create Drizzle migrations for all tables
- [x] Apply database migrations via webdev_execute_sql

## Backend Development
- [x] Create tRPC procedures for video feed
- [x] Create tRPC procedures for video upload
- [x] Create tRPC procedures for comments
- [x] Create tRPC procedures for likes
- [x] Create tRPC procedures for subscriptions
- [x] Create tRPC procedures for coins system
- [x] Create tRPC procedures for user profile
- [ ] Create tRPC procedures for admin panel
- [ ] Implement email notification system

## Frontend - Core
- [x] Set up dark purple theme
- [x] Create Home/Feed page with vertical video stream
- [x] Create Profile page
- [ ] Create Settings page
- [x] Create Admin Dashboard
- [x] Create Video Upload page

## Frontend - Features
- [x] Implement vertical scrolling video feed with auto-play
- [ ] Implement like functionality with Ajax
- [ ] Implement comment system with Ajax
- [ ] Implement subscription/follow system
- [ ] Implement coin gifting interface
- [x] Implement profile editing

## File Upload & Storage
- [ ] Implement video upload to S3
- [ ] Implement profile picture upload to S3
- [ ] Add file validation

## Testing & Optimization
- [x] Write Vitest tests
- [ ] Test all Ajax interactions
- [ ] Performance optimization
- [ ] Final testing and bug fixes

## Google OAuth & Admin Setup
- [x] Configure Google OAuth integration (already integrated via Manus OAuth)
- [x] Add first user auto-admin logic
- [x] Update login page with Google button
- [ ] Create zip archive of project
