import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Upload as UploadIcon, X } from "lucide-react";

export default function Upload() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    videoUrl: "",
    thumbnailUrl: "",
  });
  const [isUploading, setIsUploading] = useState(false);

  const createVideoMutation = trpc.videos.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUploading(true);
    try {
      await createVideoMutation.mutateAsync(formData);
      setFormData({ title: "", description: "", videoUrl: "", thumbnailUrl: "" });
      navigate("/profile");
    } catch (error) {
      console.error("Failed to upload video:", error);
    } finally {
      setIsUploading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">Будь ласка, увійдіть</p>
          <Button onClick={() => navigate("/")} className="bg-purple-600 hover:bg-purple-700">
            На головну
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black">
      {/* Header */}
      <div className="bg-gradient-to-b from-purple-900 to-transparent p-6 border-b border-purple-800">
        <Button
          variant="ghost"
          className="text-white hover:bg-purple-800 mb-4"
          onClick={() => navigate("/")}
        >
          ← Назад
        </Button>
      </div>

      {/* Upload Form */}
      <div className="max-w-2xl mx-auto p-6">
        <div className="bg-gradient-to-r from-purple-900 to-purple-800 rounded-lg p-8">
          <h1 className="text-3xl font-bold text-white mb-6">Завантажити відео</h1>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Video URL */}
            <div>
              <label className="block text-white font-semibold mb-2">Посилання на відео</label>
              <input
                type="url"
                placeholder="https://example.com/video.mp4"
                value={formData.videoUrl}
                onChange={(e) => setFormData({ ...formData, videoUrl: e.target.value })}
                className="w-full bg-purple-950 text-white rounded px-4 py-3 border border-purple-700 focus:border-pink-500 focus:outline-none"
                required
              />
              <p className="text-purple-300 text-sm mt-1">Завантажте відео на S3 або використовуйте публічне посилання</p>
            </div>

            {/* Thumbnail URL */}
            <div>
              <label className="block text-white font-semibold mb-2">Посилання на мініатюру (опціонально)</label>
              <input
                type="url"
                placeholder="https://example.com/thumbnail.jpg"
                value={formData.thumbnailUrl}
                onChange={(e) => setFormData({ ...formData, thumbnailUrl: e.target.value })}
                className="w-full bg-purple-950 text-white rounded px-4 py-3 border border-purple-700 focus:border-pink-500 focus:outline-none"
              />
            </div>

            {/* Title */}
            <div>
              <label className="block text-white font-semibold mb-2">Назва відео</label>
              <input
                type="text"
                placeholder="Введіть назву відео"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-purple-950 text-white rounded px-4 py-3 border border-purple-700 focus:border-pink-500 focus:outline-none"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-white font-semibold mb-2">Опис (опціонально)</label>
              <textarea
                placeholder="Напишіть опис вашого відео"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-purple-950 text-white rounded px-4 py-3 border border-purple-700 focus:border-pink-500 focus:outline-none"
                rows={5}
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isUploading}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2"
            >
              <UploadIcon size={20} />
              {isUploading ? "Завантаження..." : "Завантажити відео"}
            </Button>
          </form>

          {/* Info Box */}
          <div className="mt-8 bg-purple-950 rounded-lg p-4 border border-purple-700">
            <h3 className="text-white font-semibold mb-2">Поради для завантаження:</h3>
            <ul className="text-purple-300 text-sm space-y-1">
              <li>• Максимальний розмір: 1 ГБ</li>
              <li>• Підтримувані формати: MP4, WebM, Ogg</li>
              <li>• Рекомендована тривалість: до 10 хвилин</li>
              <li>• Вертикальний формат (9:16) виглядає краще</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
