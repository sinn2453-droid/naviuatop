import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Users, Video, AlertCircle, Settings } from "lucide-react";

interface AdminStats {
  totalUsers: number;
  totalVideos: number;
  totalComments: number;
  recentRegistrations: number;
}

export default function Admin() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("dashboard");

  // Check if user is admin
  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black flex items-center justify-center">
        <div className="text-center">
          <AlertCircle size={48} className="text-red-500 mx-auto mb-4" />
          <p className="text-white text-xl mb-4">Доступ заборонений</p>
          <p className="text-purple-300 mb-6">Тільки адміністратори можуть переглядати цю сторінку</p>
          <Button onClick={() => navigate("/")} className="bg-purple-600 hover:bg-purple-700">
            На головну
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black">
      {/* Header */}
      <div className="bg-gradient-to-b from-purple-900 to-transparent p-6 border-b border-purple-800">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-white">Адмін-панель</h1>
          <Button
            variant="ghost"
            className="text-white hover:bg-purple-800"
            onClick={() => navigate("/")}
          >
            ← Назад
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-purple-900 border-b border-purple-800 p-4">
        <div className="max-w-7xl mx-auto flex gap-4">
          <button
            onClick={() => setActiveTab("dashboard")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
              activeTab === "dashboard"
                ? "bg-pink-500 text-white"
                : "text-purple-300 hover:bg-purple-800"
            }`}
          >
            <Settings size={20} />
            Панель керування
          </button>
          <button
            onClick={() => setActiveTab("users")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
              activeTab === "users"
                ? "bg-pink-500 text-white"
                : "text-purple-300 hover:bg-purple-800"
            }`}
          >
            <Users size={20} />
            Користувачі
          </button>
          <button
            onClick={() => setActiveTab("videos")}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition ${
              activeTab === "videos"
                ? "bg-pink-500 text-white"
                : "text-purple-300 hover:bg-purple-800"
            }`}
          >
            <Video size={20} />
            Відео
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-6">
        {activeTab === "dashboard" && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Статистика</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Stats Cards */}
              <div className="bg-gradient-to-br from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
                <p className="text-purple-300 text-sm mb-2">Всього користувачів</p>
                <p className="text-4xl font-bold text-white">0</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
                <p className="text-purple-300 text-sm mb-2">Всього відео</p>
                <p className="text-4xl font-bold text-white">0</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
                <p className="text-purple-300 text-sm mb-2">Всього коментарів</p>
                <p className="text-4xl font-bold text-white">0</p>
              </div>
              <div className="bg-gradient-to-br from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
                <p className="text-purple-300 text-sm mb-2">Нові реєстрації (24г)</p>
                <p className="text-4xl font-bold text-white">0</p>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="mt-8">
              <h3 className="text-xl font-bold text-white mb-4">Недавна активність</h3>
              <div className="bg-gradient-to-r from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
                <p className="text-purple-300">Немає нової активності</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Управління користувачами</h2>
            <div className="bg-gradient-to-r from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
              <div className="overflow-x-auto">
                <table className="w-full text-white">
                  <thead>
                    <tr className="border-b border-purple-700">
                      <th className="text-left py-3 px-4">ID</th>
                      <th className="text-left py-3 px-4">Ім'я</th>
                      <th className="text-left py-3 px-4">Email</th>
                      <th className="text-left py-3 px-4">Роль</th>
                      <th className="text-left py-3 px-4">Дії</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-purple-700 hover:bg-purple-700 transition">
                      <td className="py-3 px-4">1</td>
                      <td className="py-3 px-4">Користувач</td>
                      <td className="py-3 px-4">user@example.com</td>
                      <td className="py-3 px-4">
                        <span className="bg-blue-600 text-white px-2 py-1 rounded text-sm">User</span>
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" className="text-red-500 hover:bg-red-900 text-sm">
                          Видалити
                        </Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "videos" && (
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Управління відео</h2>
            <div className="bg-gradient-to-r from-purple-900 to-purple-800 rounded-lg p-6 border border-purple-700">
              <div className="overflow-x-auto">
                <table className="w-full text-white">
                  <thead>
                    <tr className="border-b border-purple-700">
                      <th className="text-left py-3 px-4">ID</th>
                      <th className="text-left py-3 px-4">Назва</th>
                      <th className="text-left py-3 px-4">Автор</th>
                      <th className="text-left py-3 px-4">Переглядів</th>
                      <th className="text-left py-3 px-4">Статус</th>
                      <th className="text-left py-3 px-4">Дії</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-purple-700 hover:bg-purple-700 transition">
                      <td className="py-3 px-4">1</td>
                      <td className="py-3 px-4">Приклад відео</td>
                      <td className="py-3 px-4">Користувач</td>
                      <td className="py-3 px-4">100</td>
                      <td className="py-3 px-4">
                        <span className="bg-green-600 text-white px-2 py-1 rounded text-sm">Активне</span>
                      </td>
                      <td className="py-3 px-4">
                        <Button variant="ghost" className="text-red-500 hover:bg-red-900 text-sm">
                          Видалити
                        </Button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
