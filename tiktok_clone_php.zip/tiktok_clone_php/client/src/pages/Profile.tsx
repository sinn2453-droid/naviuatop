import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Users, Heart, Eye, Gift } from "lucide-react";

export default function Profile() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || "",
    bio: "",
    profilePicture: user?.profilePicture || "",
  });

  const { data: userProfile } = trpc.user.getProfile.useQuery(
    { id: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const { data: userVideos } = trpc.videos.getUserVideos.useQuery(
    { userId: user?.id || 0 },
    { enabled: !!user?.id }
  );

  const updateProfileMutation = trpc.user.updateProfile.useMutation();

  const handleUpdateProfile = async () => {
    try {
      await updateProfileMutation.mutateAsync(formData);
      setIsEditing(false);
    } catch (error) {
      console.error("Failed to update profile:", error);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl mb-4">Будь ласка, увійдіть</p>
          <Button onClick={() => navigate("/")} className="bg-purple-600 hover:bg-purple-700">
            На головну
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black">
      {/* Header */}
      <div className="bg-gradient-to-b from-purple-900 to-transparent p-6 border-b border-purple-800">
        <Button
          variant="ghost"
          className="text-white hover:bg-purple-800 mb-4"
          onClick={() => navigate("/")}
        >
          ← Назад
        </Button>
      </div>

      {/* Profile Section */}
      <div className="max-w-2xl mx-auto p-6">
        {/* Profile Header */}
        <div className="bg-gradient-to-r from-purple-900 to-purple-800 rounded-lg p-8 mb-6">
          <div className="flex items-center gap-6 mb-6">
            <div className="w-24 h-24 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
              {userProfile?.profilePicture ? (
                <img src={userProfile.profilePicture} alt="Profile" className="w-full h-full rounded-full object-cover" />
              ) : (
                <span className="text-4xl text-white font-bold">{user?.name?.charAt(0).toUpperCase()}</span>
              )}
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-white mb-2">{user?.name || "Користувач"}</h1>
              <p className="text-purple-300 mb-4">@{user?.email?.split("@")[0]}</p>
              {isEditing ? (
                <div className="space-y-3">
                  <input
                    type="text"
                    placeholder="Ім'я"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-purple-950 text-white rounded px-3 py-2 border border-purple-700"
                  />
                  <textarea
                    placeholder="Біографія"
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    className="w-full bg-purple-950 text-white rounded px-3 py-2 border border-purple-700"
                    rows={3}
                  />
                  <div className="flex gap-2">
                    <Button
                      onClick={handleUpdateProfile}
                      className="bg-pink-500 hover:bg-pink-600 text-white"
                    >
                      Зберегти
                    </Button>
                    <Button
                      onClick={() => setIsEditing(false)}
                      variant="outline"
                      className="text-white border-purple-700 hover:bg-purple-800"
                    >
                      Скасувати
                    </Button>
                  </div>
                </div>
              ) : (
                <Button
                  onClick={() => setIsEditing(true)}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  Редагувати профіль
                </Button>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-4 pt-6 border-t border-purple-700">
            <div className="text-center">
              <p className="text-2xl font-bold text-white">{userVideos?.length || 0}</p>
              <p className="text-purple-300 text-sm">Відео</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1">
                <Users size={20} className="text-pink-500" />
                <p className="text-2xl font-bold text-white">{userProfile?.followerCount || 0}</p>
              </div>
              <p className="text-purple-300 text-sm">Підписники</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1">
                <Heart size={20} className="text-red-500" />
                <p className="text-2xl font-bold text-white">0</p>
              </div>
              <p className="text-purple-300 text-sm">Лайки</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1">
                <Gift size={20} className="text-yellow-500" />
                <p className="text-2xl font-bold text-white">{userProfile?.coinBalance || 0}</p>
              </div>
              <p className="text-purple-300 text-sm">Монети</p>
            </div>
          </div>
        </div>

        {/* Videos Section */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4">Мої відео</h2>
          {userVideos && userVideos.length > 0 ? (
            <div className="grid grid-cols-2 gap-4">
              {userVideos.map((video: any) => (
                <div key={video.id} className="bg-purple-900 rounded-lg overflow-hidden hover:shadow-lg transition">
                  <div className="relative pb-[100%]">
                    <img
                      src={video.thumbnailUrl || "https://via.placeholder.com/300x400"}
                      alt={video.title}
                      className="w-full h-40 object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-40 transition flex items-center justify-center">
                      <Eye size={32} className="text-white opacity-0 hover:opacity-100" />
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="text-white font-semibold truncate">{video.title}</h3>
                    <p className="text-purple-300 text-sm">{video.viewCount} переглядів</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-purple-300 mb-4">Ви ще не завантажили жодного відео</p>
              <Button
                onClick={() => navigate("/upload")}
                className="bg-pink-500 hover:bg-pink-600 text-white"
              >
                Завантажити перше відео
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
