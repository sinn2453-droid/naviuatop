import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import { Heart, MessageCircle, Share2, Gift, Volume2, VolumeX } from "lucide-react";

interface VideoItem {
  id: number;
  userId: number;
  title: string;
  description?: string;
  videoUrl: string;
  thumbnailUrl?: string;
  likeCount: number;
  commentCount: number;
  viewCount: number;
  createdAt: Date;
}

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [videos, setVideos] = useState<VideoItem[]>([]);
  const [currentVideoIndex, setCurrentVideoIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);

  const { data: feedData } = trpc.videos.feed.useQuery({ limit: 20, offset: 0 });

  useEffect(() => {
    if (feedData) {
      setVideos(feedData as VideoItem[]);
    }
  }, [feedData]);

  useEffect(() => {
    const handleScroll = (e: WheelEvent) => {
      if (e.deltaY > 0 && currentVideoIndex < videos.length - 1) {
        setCurrentVideoIndex(currentVideoIndex + 1);
      } else if (e.deltaY < 0 && currentVideoIndex > 0) {
        setCurrentVideoIndex(currentVideoIndex - 1);
      }
    };

    window.addEventListener("wheel", handleScroll, { passive: true });
    return () => window.removeEventListener("wheel", handleScroll);
  }, [currentVideoIndex, videos.length]);

  useEffect(() => {
    // Auto-play current video
    if (videoRefs.current[currentVideoIndex]) {
      videoRefs.current[currentVideoIndex]?.play();
    }
    // Pause other videos
    videoRefs.current.forEach((video, index) => {
      if (index !== currentVideoIndex && video) {
        video.pause();
      }
    });
  }, [currentVideoIndex]);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black flex flex-col items-center justify-center">
        <div className="text-center max-w-md">
          <div className="mb-8">
            <h1 className="text-6xl font-bold text-white mb-4">TikTok Clone</h1>
            <p className="text-xl text-purple-300 mb-2">Поділіться своїми відео</p>
            <p className="text-sm text-purple-400">з усім світом</p>
          </div>

          <div className="space-y-4">
            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-4 rounded-full text-lg font-semibold flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Увійти через Google
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-purple-700"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-purple-950 text-purple-400">або</span>
              </div>
            </div>

            <Button
              onClick={() => (window.location.href = getLoginUrl())}
              variant="outline"
              className="w-full border-purple-700 text-white hover:bg-purple-900 px-8 py-4 rounded-full text-lg font-semibold"
            >
              Зареєструватися
            </Button>
          </div>

          <p className="text-xs text-purple-400 mt-6">
            Натиснувши на кнопку, ви погоджуєтесь з нашими умовами використання
          </p>
        </div>
      </div>
    );
  }

  if (videos.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-950 via-purple-900 to-black flex items-center justify-center">
        <div className="text-center">
          <p className="text-white text-xl">Завантаження відео...</p>
        </div>
      </div>
    );
  }

  const currentVideo = videos[currentVideoIndex];

  return (
    <div className="min-h-screen bg-black overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-purple-950 to-transparent">
        <div className="flex items-center justify-between p-4 max-w-7xl mx-auto">
          <h1 className="text-2xl font-bold text-white">TikTok Clone</h1>
          <div className="flex gap-4">
            <Button
              variant="ghost"
              className="text-white hover:bg-purple-800"
              onClick={() => navigate("/profile")}
            >
              Профіль
            </Button>
            <Button
              variant="ghost"
              className="text-white hover:bg-purple-800"
              onClick={() => navigate("/upload")}
            >
              Завантажити
            </Button>
            {user?.role === "admin" && (
              <Button
                variant="ghost"
                className="text-white hover:bg-purple-800"
                onClick={() => navigate("/admin")}
              >
                Адмін
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Video Feed */}
      <div className="h-screen w-full relative">
        <video
          ref={(el) => {
            if (el) videoRefs.current[currentVideoIndex] = el;
          }}
          src={currentVideo.videoUrl}
          className="w-full h-full object-cover"
          muted={isMuted}
          loop
          playsInline
        />

        {/* Video Info */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
          <h2 className="text-white text-xl font-bold mb-2">{currentVideo.title}</h2>
          <p className="text-gray-300 text-sm mb-4">{currentVideo.description}</p>
        </div>

        {/* Right Side Actions */}
        <div className="absolute right-4 bottom-20 flex flex-col gap-6">
          <button className="flex flex-col items-center gap-2 text-white hover:text-pink-500 transition">
            <div className="bg-purple-600 rounded-full p-3 hover:bg-purple-700">
              <Heart size={24} />
            </div>
            <span className="text-xs">{currentVideo.likeCount}</span>
          </button>

          <button className="flex flex-col items-center gap-2 text-white hover:text-blue-500 transition">
            <div className="bg-purple-600 rounded-full p-3 hover:bg-purple-700">
              <MessageCircle size={24} />
            </div>
            <span className="text-xs">{currentVideo.commentCount}</span>
          </button>

          <button className="flex flex-col items-center gap-2 text-white hover:text-yellow-500 transition">
            <div className="bg-purple-600 rounded-full p-3 hover:bg-purple-700">
              <Gift size={24} />
            </div>
            <span className="text-xs">Дар</span>
          </button>

          <button
            onClick={() => setIsMuted(!isMuted)}
            className="flex flex-col items-center gap-2 text-white hover:text-green-500 transition"
          >
            <div className="bg-purple-600 rounded-full p-3 hover:bg-purple-700">
              {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
            </div>
          </button>
        </div>

        {/* Progress Bar */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-700">
          <div
            className="h-full bg-gradient-to-r from-pink-500 to-purple-600"
            style={{ width: `${((currentVideoIndex + 1) / videos.length) * 100}%` }}
          />
        </div>
      </div>
    </div>
  );
}
