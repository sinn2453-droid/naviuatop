import { describe, it, expect, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `test-user-${userId}`,
    email: `test${userId}@example.com`,
    name: `Test User ${userId}`,
    loginMethod: "test",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("Videos API", () => {
  describe("videos.feed", () => {
    it("should return empty array when no videos exist", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.videos.feed({ limit: 20, offset: 0 });
      expect(Array.isArray(result)).toBe(true);
    });

    it("should accept limit and offset parameters", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.videos.feed({ limit: 10, offset: 5 });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("videos.getById", () => {
    it("should return null for non-existent video", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.videos.getById({ id: 99999 });
      expect(result).toBeNull();
    });
  });

  describe("videos.getUserVideos", () => {
    it("should return array for user videos", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.videos.getUserVideos({ userId: 1 });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("videos.create", () => {
    it("should require authentication", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: () => {} } as TrpcContext["res"],
      };
      const caller = appRouter.createCaller(ctx);
      
      try {
        await caller.videos.create({
          title: "Test Video",
          videoUrl: "https://example.com/video.mp4",
        });
        expect.fail("Should have thrown error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should accept video creation with required fields", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      
      try {
        const result = await caller.videos.create({
          title: "Test Video",
          videoUrl: "https://example.com/video.mp4",
        });
        expect(result).toHaveProperty("success");
      } catch (error) {
        // Expected to fail due to database not being available in test
        expect(error).toBeDefined();
      }
    });
  });
});

describe("Comments API", () => {
  describe("comments.getByVideo", () => {
    it("should return empty array for video with no comments", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.comments.getByVideo({ videoId: 1 });
      expect(Array.isArray(result)).toBe(true);
    });
  });
});

describe("Subscriptions API", () => {
  describe("subscriptions.isFollowing", () => {
    it("should return false when user is not following", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.subscriptions.isFollowing({
        followerId: 1,
        followingId: 2,
      });
      expect(result).toBe(false);
    });
  });
});

describe("User API", () => {
  describe("user.getProfile", () => {
    it("should return null for non-existent user", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);
      const result = await caller.user.getProfile({ id: 99999 });
      expect(result).toBeNull();
    });
  });

  describe("user.updateProfile", () => {
    it("should require authentication", async () => {
      const ctx: TrpcContext = {
        user: null,
        req: { protocol: "https", headers: {} } as TrpcContext["req"],
        res: { clearCookie: () => {} } as TrpcContext["res"],
      };
      const caller = appRouter.createCaller(ctx);
      
      try {
        await caller.user.updateProfile({
          name: "Updated Name",
        });
        expect.fail("Should have thrown error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});
