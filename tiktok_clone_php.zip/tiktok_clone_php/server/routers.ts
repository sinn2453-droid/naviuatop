import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { videos, comments, likes, subscriptions, gifts, coinTransactions, users } from "../drizzle/schema";
import { eq, and, desc } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // Video procedures
  videos: router({
    feed: publicProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return await db.select().from(videos).where(eq(videos.isPublic, true)).orderBy(desc(videos.createdAt)).limit(input.limit).offset(input.offset);
      }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const result = await db.select().from(videos).where(eq(videos.id, input.id)).limit(1);
        return result.length > 0 ? result[0] : null;
      }),
    
    getUserVideos: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return await db.select().from(videos).where(and(eq(videos.userId, input.userId), eq(videos.isPublic, true))).orderBy(desc(videos.createdAt));
      }),
    
    create: protectedProcedure
      .input(z.object({ 
        title: z.string(), 
        description: z.string().optional(), 
        videoUrl: z.string(), 
        thumbnailUrl: z.string().optional(), 
        duration: z.number().optional() 
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.insert(videos).values({ ...input, userId: ctx.user.id, isPublic: true });
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const video = await db.select().from(videos).where(eq(videos.id, input.id)).limit(1);
        if (video.length === 0 || video[0].userId !== ctx.user.id) throw new Error("Unauthorized");
        await db.delete(videos).where(eq(videos.id, input.id));
        return { success: true };
      }),
  }),

  // Comment procedures
  comments: router({
    getByVideo: publicProcedure
      .input(z.object({ videoId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        return await db.select().from(comments).where(eq(comments.videoId, input.videoId)).orderBy(desc(comments.createdAt));
      }),
    
    create: protectedProcedure
      .input(z.object({ videoId: z.number(), content: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.insert(comments).values({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const comment = await db.select().from(comments).where(eq(comments.id, input.id)).limit(1);
        if (comment.length === 0 || comment[0].userId !== ctx.user.id) throw new Error("Unauthorized");
        await db.delete(comments).where(eq(comments.id, input.id));
        return { success: true };
      }),
  }),

  // Like procedures
  likes: router({
    toggle: protectedProcedure
      .input(z.object({ videoId: z.number().optional(), commentId: z.number().optional() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        let whereClause;
        if (input.videoId) {
          whereClause = and(eq(likes.userId, ctx.user.id), eq(likes.videoId, input.videoId));
        } else if (input.commentId) {
          whereClause = and(eq(likes.userId, ctx.user.id), eq(likes.commentId, input.commentId));
        } else {
          throw new Error("Either videoId or commentId is required");
        }
        const existing = await db.select().from(likes).where(whereClause).limit(1);
        if (existing.length > 0) {
          await db.delete(likes).where(eq(likes.id, existing[0].id));
          return { liked: false };
        } else {
          await db.insert(likes).values({ userId: ctx.user.id, ...input });
          return { liked: true };
        }
      }),
  }),

  // Subscription procedures
  subscriptions: router({
    toggle: protectedProcedure
      .input(z.object({ userId: z.number() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const existing = await db.select().from(subscriptions).where(and(eq(subscriptions.followerId, ctx.user.id), eq(subscriptions.followingId, input.userId))).limit(1);
        if (existing.length > 0) {
          await db.delete(subscriptions).where(eq(subscriptions.id, existing[0].id));
          return { following: false };
        } else {
          await db.insert(subscriptions).values({ followerId: ctx.user.id, followingId: input.userId });
          return { following: true };
        }
      }),
    
    isFollowing: publicProcedure
      .input(z.object({ followerId: z.number(), followingId: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return false;
        const result = await db.select().from(subscriptions).where(and(eq(subscriptions.followerId, input.followerId), eq(subscriptions.followingId, input.followingId))).limit(1);
        return result.length > 0;
      }),
  }),

  // Gifts procedures
  gifts: router({
    send: protectedProcedure
      .input(z.object({ 
        recipientId: z.number(), 
        giftType: z.string(), 
        coinAmount: z.number(), 
        videoId: z.number().optional(), 
        message: z.string().optional() 
      }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const sender = await db.select().from(users).where(eq(users.id, ctx.user.id)).limit(1);
        if (sender.length === 0 || sender[0].coinBalance < input.coinAmount) throw new Error("Insufficient coins");
        await db.insert(gifts).values({ senderId: ctx.user.id, ...input });
        await db.update(users).set({ coinBalance: sender[0].coinBalance - input.coinAmount }).where(eq(users.id, ctx.user.id));
        const recipient = await db.select().from(users).where(eq(users.id, input.recipientId)).limit(1);
        if (recipient.length > 0) {
          await db.update(users).set({ coinBalance: recipient[0].coinBalance + input.coinAmount }).where(eq(users.id, input.recipientId));
        }
        return { success: true };
      }),
  }),

  // User procedures
  user: router({
    getProfile: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return null;
        const result = await db.select().from(users).where(eq(users.id, input.id)).limit(1);
        return result.length > 0 ? result[0] : null;
      }),
    
    updateProfile: protectedProcedure
      .input(z.object({ name: z.string().optional(), bio: z.string().optional(), profilePicture: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db.update(users).set(input).where(eq(users.id, ctx.user.id));
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
